package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Person;
import com.example.demo.repsitory.JdbcRepository;

@Service
public class EmployeeService {

	@Autowired
	JdbcRepository jdbcRepository;

	public List<Person> getAllEmployee() {
		return jdbcRepository.findAll();
	}

	public Person getEmployeeById(int id) {
		return jdbcRepository.findById(id);
	}

	public int deleteEmployeeById(int id) {
		return jdbcRepository.deleteById(id);
	}

	public Person createEmployee(Person person) {
		Person checkPerson = jdbcRepository.findById(person.getId());
		if (checkPerson == null) {
			jdbcRepository.insert(person);
			System.out.println(jdbcRepository.insert(person));
			return person;
		} else {
			System.out.println(jdbcRepository.update(person));
			return checkPerson;
		}

	}
}
