package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jca.cci.RecordTypeNotSupportedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Person;
import com.example.demo.services.EmployeeService;

@RestController
@RequestMapping("/employee")
public class PersonController {

	@Autowired
	EmployeeService employeeService;

	@GetMapping("/getAll")
	public List<Person> getAllEmployee() {
		return employeeService.getAllEmployee();
	}

	@GetMapping("/get")
	public ResponseEntity<List<Person>> getAll() {
		List<Person> person = employeeService.getAllEmployee();
		return new ResponseEntity<List<Person>>(person, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Person> getEmployeeById(@PathVariable("id") int id) throws Exception {
		Person person = employeeService.getEmployeeById(id);
		return new ResponseEntity<Person>(person, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping("/delete/{id}")
	public ResponseEntity<Integer> deleteEmployeeById(@PathVariable("id") int id) throws Exception {
		return new ResponseEntity<Integer>(employeeService.deleteEmployeeById(id), new HttpHeaders(), HttpStatus.OK);
	}
	@PostMapping(path="/create")
	public ResponseEntity<Person> createEmployee(Person person) {
		System.out.println("create");
		Person personUpdated=employeeService.createEmployee(person);
		
		return new ResponseEntity<Person>(personUpdated ,new HttpHeaders(),HttpStatus.OK);
	}
	@PostMapping(path="/update")
	public ResponseEntity<Person> updateEmployee(Person person) {
		Person personUpdated=employeeService.createEmployee(person);
		System.out.println("update");
		return new ResponseEntity<Person>(personUpdated ,new HttpHeaders(),HttpStatus.OK);
	}
}
