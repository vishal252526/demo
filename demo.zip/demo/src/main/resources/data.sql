insert into person(id,name,location)
VALUES(11,"sandy","TeaNeck");
insert into person(id,name,location)
VALUES(12,"jack","amsterdam");


